"""Embedding service for multiple LLM providers.

This module provides dense embedding generation supporting:
- OpenAI (text-embedding-3-large)
- Azure OpenAI
- Google Gemini
- Voyage AI

Embeddings are used for semantic similarity search in product recommendations.
"""

from typing import Any, Dict, List

from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain_openai import AzureOpenAIEmbeddings, OpenAIEmbeddings
from pydantic import SecretStr

from cadence_sdk import Loggable


class EmbeddingService(Loggable):
    """Provides dense embedding generation for semantic search.

    Supports multiple embedding providers with automatic provider selection
    based on configuration. Embeddings enable semantic similarity matching
    for natural language product queries.
    """

    PROVIDER_OPENAI = ["openai"]
    PROVIDER_AZURE = ["azure", "azure-openai"]

    def __init__(self, config: Dict[str, Any]):
        super().__init__()
        self.config = config
        self.embedding_provider = self._create_embedding_provider(config)

    @staticmethod
    def _resolve_api_key(config: Dict[str, Any], provider: str) -> str | None:
        """Resolve API key for the given provider from config."""
        key_map = {
            "openai": "embedding_provider_openai_api_key",
            "azure-openai": "embedding_provider_azure_openai_api_key",
            "azure": "embedding_provider_azure_openai_api_key",
        }
        key_name = key_map.get(provider)
        return config.get(key_name) if key_name else None

    def _resolve_model(self, config: Dict[str, Any], provider: str) -> str:
        """Resolve model name for the given provider from config."""
        model_map = {
            "openai": "embedding_provider_openai_model",
            "azure": "embedding_provider_azure_openai_deployment",
            "azure-openai": "embedding_provider_azure_openai_deployment",
        }
        key_name = model_map.get(provider)
        default = (
            "text-embedding-3-large"
            if provider in self.PROVIDER_OPENAI + self.PROVIDER_AZURE
            else (
                "voyage-3-large"
                if provider in self.PROVIDER_VOYAGE
                else "gemini-embedding-001"
            )
        )
        return config.get(key_name, default) if key_name else default

    def _create_embedding_provider(
        self, config: Dict[str, Any]
    ) -> GoogleGenerativeAIEmbeddings | OpenAIEmbeddings | AzureOpenAIEmbeddings:
        """Create embedding provider instance based on configuration."""
        provider = (config.get("embedding_provider") or "azure").lower()
        api_key = self._resolve_api_key(config, provider)
        if not api_key:
            raise ValueError(f"No API key found for embedding provider: {provider}")

        model = self._resolve_model(config, provider)

        if provider in self.PROVIDER_OPENAI:
            return self._create_openai_embeddings(model, api_key)
        elif provider in self.PROVIDER_AZURE:
            return self._create_azure_embeddings(model, api_key, config)
        else:
            raise ValueError(f"Unknown embedding provider: {provider}")

    @staticmethod
    def _create_openai_embeddings(model: str, api_key: str) -> OpenAIEmbeddings:
        """Create OpenAI embedding provider."""
        return OpenAIEmbeddings(model=model, api_key=SecretStr(api_key))

    @staticmethod
    def _create_azure_embeddings(
        model: str, api_key: str, config: Dict[str, Any]
    ) -> AzureOpenAIEmbeddings:
        """Create Azure OpenAI embedding provider."""
        return AzureOpenAIEmbeddings(
            model=model,
            api_key=SecretStr(api_key),
            azure_endpoint=config.get("embedding_provider_azure_openai_endpoint"),
            azure_deployment=config.get(
                "embedding_provider_azure_openai_deployment", "text-embedding-3-large"
            ),
            api_version=config.get(
                "embedding_provider_azure_openai_api_version", "2025-04-01-preview"
            ),
        )

    async def get_embedding_query(self, query: str) -> List[float]:
        """Generate embedding vector for search query."""
        collection = self.config.get("qdrant_collection_name", "")
        url = self.config.get("qdrant_url", "")
        self.logger.info(
            f"Generating embedding for query in collection {collection} on server {url}"
        )
        return await self.embedding_provider.aembed_query(query)
