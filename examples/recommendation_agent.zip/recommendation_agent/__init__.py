"""Product Recommendation Plugin for shop.api.de IT products and hardware solutions.

This plugin provides comprehensive product search and retrieval capabilities
for IT hardware, components, networking equipment, peripherals, and accessories.
"""

from .plugin import ProductRecommendationPlugin
from .schemas import (
    RecommendationSearchInput,
    ResourceByIdInput,
    ResourceByUrlInput,
    SearchTerm,
)

__all__ = [
    "ProductRecommendationPlugin",
    "RecommendationSearchInput",
    "ResourceByIdInput",
    "ResourceByUrlInput",
    "SearchTerm",
]
