"""Template plugin package."""

from .plugin import TemplatePlugin

__all__ = ["TemplatePlugin"]
